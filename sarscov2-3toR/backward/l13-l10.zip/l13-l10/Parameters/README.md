Config files for both AMBER and QUBE free energy simulations.
